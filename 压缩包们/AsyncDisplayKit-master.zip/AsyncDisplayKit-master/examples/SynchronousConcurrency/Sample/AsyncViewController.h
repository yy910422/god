//
//  AsyncViewController.h
//  Sample
//
//  Created by Scott Goodson on 9/26/15.
//  Copyright © 2015 Facebook. All rights reserved.
//

#import "ASViewController.h"

@interface AsyncViewController : ASViewController <UITabBarControllerDelegate>

@end
