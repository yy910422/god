//
//  MLNavigationController.swift
//  Sojexlos
//
//  Created by sojex on 14-7-3.
//  Copyright (c) 2014年 sojex. All rights reserved.
//

import Foundation
import UIKit

class MLNavigationController: UINavigationController, UIGestureRecognizerDelegate {
    
    var canDragBack: Bool = true;
    var screenShotsList = NSMutableArray();
    var backgroundView_Y = NSMutableArray();
    
    var backgroundView: UIView?;
    var blackMask: UIView?;
    var lastScreenShotView: UIImageView?;

    var recognizer: UIPanGestureRecognizer!;

    //标记是否移动
    var isMoving: Bool = false;
    var startTouch: CGPoint?;
    
    
    init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!)  {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil);
        
        self.recognizer = UIPanGestureRecognizer(target: self, action: "paningGestureReceive:");
        self.recognizer!.delegate = self;
        self.view!.addGestureRecognizer(recognizer!);
    }
    
    init(rootViewController: UIViewController!) {
        super.init(rootViewController: rootViewController);
    }
    
    
    override func viewDidLoad()  {
        super.viewDidLoad();
    }
    
    
    override func pushViewController(viewController: UIViewController!, animated: Bool) {
        super.pushViewController(viewController, animated:animated)
        
        self.view!.removeGestureRecognizer(recognizer);
        
        addImage();
        self.view!.addGestureRecognizer(recognizer);
    }
    
    override func popViewControllerAnimated(animated: Bool) -> UIViewController! {
        self.screenShotsList.removeLastObject();
        
        return super.popViewControllerAnimated(animated);
    }
    
    
    
    func addImage() {
        self.screenShotsList.addObject(capture());
    }
    
    // get the current view screen shot
    func capture() -> UIImage {
        
        let controllers: NSArray = self.viewControllers;
        
        var vc: UIViewController?;
        if (controllers.count > 2) {
            vc = controllers.objectAtIndex(controllers.count - 2) as? UIViewController;
        }
        else {
            vc = controllers.objectAtIndex(0) as? UIViewController;
        }
        
        UIGraphicsBeginImageContextWithOptions(vc!.view.bounds.size, true, 0.0);
        vc!.view.layer.renderInContext(UIGraphicsGetCurrentContext());
        
        let uiImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        return uiImage;
    }
    
    
    func paningGestureReceive(recoginzer: UIPanGestureRecognizer) {
        
        if (self.viewControllers.count < 1 || !canDragBack) {
            return;
        }
        
        let keyWindow = (UIApplication.sharedApplication()).keyWindow;
        var touchPoint = recoginzer.locationInView(keyWindow);
        
        if (recoginzer.state == UIGestureRecognizerState.Began) {
            isMoving = true;
            startTouch = touchPoint;
            
            if (!backgroundView) {
                backgroundView = UIView(frame: self.view.frame);
                self.view!.superview!.insertSubview(backgroundView!, belowSubview: self.view!);
            }
            backgroundView!.hidden = false;
            
            if (!blackMask) {
                blackMask = UIView(frame: backgroundView!.frame);
                backgroundView!.addSubview(blackMask!);
            }
            
            if (lastScreenShotView) {
                lastScreenShotView!.removeFromSuperview();
            }
            
            let lastScreenImage: UIImage = self.screenShotsList.lastObject as UIImage;
            lastScreenShotView = UIImageView(image: lastScreenImage);
            lastScreenShotView!.frame = backgroundView!.frame;
            
            backgroundView!.insertSubview(lastScreenShotView!, belowSubview: blackMask!);
            
        }
        else if (recoginzer.state == UIGestureRecognizerState.Ended) {
            if (touchPoint.x - startTouch!.x > 50)
            {
                UIView.animateWithDuration(0.3, animations: {
                    self.moveViewWithX(320);
                    }, completion: {(Bool completion) in
                        
//                        let controllers: NSArray = self.viewControllers;
//                        var vc = controllers.lastObject;
                        
                        self.popViewControllerAnimated(false);
        
                        var frame = self.view.frame;
                        frame.origin.x = 0;
                        self.view.frame = frame;
                        self.backgroundView!.hidden = true;
                        
                        self.isMoving = false;
                    });
            }
            else {
                UIView.animateWithDuration(0.3, animations: {
                    self.moveViewWithX(0);
                    }, completion: {(Bool completion) in
                        
                        self.backgroundView!.hidden = true;
                        self.isMoving = false;
                    });
            }
            return;
        }
        else if (recoginzer.state == UIGestureRecognizerState.Cancelled){
            
            UIView.animateWithDuration(0.3, animations: {
                self.moveViewWithX(0);
                }, completion: {(Bool completion) in
                    
                    self.backgroundView!.hidden = true;
                    self.isMoving = false;
                });
            return;
        }
        
        if (isMoving) {
            moveViewWithX(touchPoint.x - startTouch!.x);
        }
        
    }
    
    
    func moveViewWithX(var x: Float) {
        
        x = x > 320 ? 320 : x;
        x = x < 0 ? 0 : x;
        
        var frame = self.view!.frame;
        frame.origin.x = x;
        self.view!.frame = frame;
        
        println("x : \(x)");
        
        var alpha = 0.4 - (x / 800);
        blackMask!.alpha = alpha;
        
        frame = lastScreenShotView!.frame;
        frame.origin.x = (x - 320) * 0.6;
        lastScreenShotView!.frame = frame;
    }
    
    
}
