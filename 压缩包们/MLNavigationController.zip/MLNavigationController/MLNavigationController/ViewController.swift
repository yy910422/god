//
//  ViewController.swift
//  Sojexlos
//
//  Created by sojex on 14-7-8.
//  Copyright (c) 2014年 sojex. All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController {
    
    init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
    }
    
    init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        // Custom initialization
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        var button  = UIButton.buttonWithType(UIButtonType.Custom) as UIButton
        button.frame = CGRectMake(100, 100, 80, 49)
        button.addTarget(self, action: "tabBarButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view!.addSubview(button);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnClick(sender : AnyObject) {
        var vc = SecoundViewController(nibName:"SecoundViewController",  bundle: nil);
        self.navigationController.pushViewController(vc, animated: true);
    }
    
    func tabBarButtonClicked(sender:UIButton)
    {
    }
}