//
//  SecoundViewController.swift
//  Sojexlos
//
//  Created by sojex on 14-7-8.
//  Copyright (c) 2014年 sojex. All rights reserved.
//

import Foundation
import UIKit

class SecoundViewController: UIViewController {
    
    init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
    }
    
    init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        // Custom initialization
    }
    
    override func viewDidLoad() {
        super.viewDidLoad();
    }
}