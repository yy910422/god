//
//  WebViewController.h
//  KeyboardTextFieldDemo

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController<UIWebViewDelegate>
{
    IBOutlet UIWebView *_webView;

}

@end
