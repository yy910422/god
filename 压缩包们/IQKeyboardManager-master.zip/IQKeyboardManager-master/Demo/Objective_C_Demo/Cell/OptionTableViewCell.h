//
//  OptionTableViewCell.h
//  IQKeyboard
//
//  Created by Iftekhar on 27/09/14.
//  Copyright (c) 2014 Iftekhar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OptionTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *labelOption;

@end
