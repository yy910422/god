//
//  Student.m
//  MJExtensionExample
//
//  Created by MJ Lee on 15/1/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "Student.h"

@implementation Student
//+ (NSDictionary *)replacedKeyFromPropertyName
//{
//    return @{@"ID" : @"id",
//             @"desc" : @"desciption",
//             @"oldName" : @"name.oldName",
//             @"nowName" : @"name.newName",
//             @"nameChangedTime" : @"name.info[1].nameChangedTime",
//             @"bag" : @"other.bag"
//             };
//}
@end
