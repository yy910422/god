//
//  Dog.m
//  MJExtensionExample
//
//  Created by MJ Lee on 15/6/7.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "Dog.h"
//#import "MJExtension.h"

@implementation Dog
//+ (NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName
//{
//    // nickName -> nick_name
//    return [propertyName underlineFromCamel];
//}
@end
