//
//  ViewController.swift
//  Reflect
//
//  Created by 冯成林 on 15/8/19.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit



class User {
    
    class Fav {
        
    }
}



class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        Book3.action()
    }


}







